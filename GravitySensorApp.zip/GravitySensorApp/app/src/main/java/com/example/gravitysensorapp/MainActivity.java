package com.example.gravitysensorapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.AudioManager;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private TextView xtextview, ytextview, ztextview;
    private SensorManager sensorManager;
    private Sensor sensGravity;
    private boolean isGravityPresent;
    private AudioManager audioManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        xtextview = findViewById(R.id.xtext);
        ytextview = findViewById(R.id.ytext);
        ztextview = findViewById(R.id.ztext);

        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);

        if (sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY)!=null)
        {
            sensGravity = sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY);
            isGravityPresent= true;
        }
        else
        {
            xtextview.setText("Sensor is not Present!!");
            isGravityPresent = false;
        }
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        xtextview.setText(sensorEvent.values[0]+ "m/s2");
        ytextview.setText(sensorEvent.values[1]+ "m/s2");
        ztextview.setText(sensorEvent.values[2]+ "m/s2");

        if (sensorEvent.values[2]<-9.7)
        {
            getWindow().getDecorView().setBackgroundColor(Color.GREEN);
            audioManager.setRingerMode(AudioManager.RINGER_MODE_VIBRATE);
        }
        else {
            getWindow().getDecorView().setBackgroundColor(Color.WHITE);
            audioManager.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }

    @Override
    protected void onResume() {
        super.onResume();
        if (sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY)!=null)
            sensorManager.registerListener(this,sensGravity,SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY)!=null)
            sensorManager.unregisterListener(this,sensGravity);
    }
}